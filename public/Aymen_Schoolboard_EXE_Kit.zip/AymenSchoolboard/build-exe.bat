@echo off
title Build Aymen Schoolboard EXE
where node >nul 2>nul || (echo Please install Node.js first: https://nodejs.org & pause & exit /b)
call npm install
if not exist lib mkdir lib
copy /Y node_modules\pdfjs-dist\build\pdf.min.js lib\ >nul
copy /Y node_modules\pdfjs-dist\build\pdf.worker.min.js lib\ >nul
call npm run dist
echo.
echo Done! Your app is in the "dist" folder: Aymen-Schoolboard.exe
pause
