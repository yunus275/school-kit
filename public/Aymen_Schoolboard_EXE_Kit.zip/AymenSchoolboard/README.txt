Aymen Schoolboard - make the EXE (Windows)
1. Install Node.js (https://nodejs.org) once.
2. Double-click build-exe.bat  (needs internet the first time).
3. Take dist\Aymen-Schoolboard.exe - one file, no install, works offline (PDF too).
Your board, drawings, PDF and Lucky Circle names are saved automatically and come back when you reopen the app.
To just test without building: run  npm install  then  npm start
